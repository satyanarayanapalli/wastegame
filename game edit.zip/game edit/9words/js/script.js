$(function()
	{
		var div1=$("#div_1");
		var div2=$("#div_2");
		var div3=$("#div_3");
		var div4=$("#div_4");
		var div5=$("#div_5");
		var div6=$("#div_6");
		var div7=$("#div_7");
		var div8=$("#div_8");
		var div9=$("#div_9");
		var text=$("#text_div");
		var new_btn=$("#new_btn");
    var show_btn=$("#show_btn");
		var time_tag=$("#times_tag");
    var restart_div=$('#restart_div');
  var restart_btn=$('#restart');



  var country=new Array(20);
      country[0] = "AUSTRALIA";
        country[1] = "GREENLAND";
        country[2] = "VALENTINE";
        country[3] = "INDONESIA";
        country[4] = "CANDIDATE";
        country[5] = "VENEZUELA";
        country[6] = "SECONDARY";
        country[7] = "FURNITURE";
        country[8] = "ARGENTINA";
        country[9] = "COOPERATE";
        country[10] = "SINGAPORE";
        country[11] = "SIGNATURE";
        country[12] = "STATEMENT";
        country[13] = "RECOGNIZE";
        country[14] = "ADVERTISE";
        country[15] = "CHOCOLATE";
        country[16] = "WEDNESDAY";
        country[17] = "CHALLENGE";
        country[18] = "ADVENTURE";
        country[19] = "IMPORTANT";


  var remain_time=20;
  var next_level=false;

		var count=0;
    var tim=20;
		
       
    var myArray = [0,1,2,3,4,5,6,7,8];
    shuffle(myArray);

    function shuffle(a) {
    for (let i = a.length; i; i--) {
        let j = Math.floor(Math.random() * i);
        [a[i - 1], a[j]] = [a[j], a[i - 1]];
    }
}

          var characters="";
   				var times=1000;
          var divboolean1=true,divboolean2=true,divboolean3=true,divboolean4=true,
          divboolean9=true,divboolean8=true,divboolean7=true,divboolean6=true,divboolean5=true;

   				requestAnimationFrame(timestart);

   				var sr = Math.floor(Math.random() * 20);


   			var name=country[sr];
   			var total_name="";

   			new_btn.click(function()
   			{
   				location.reload();
   			});

        show_btn.click(function()
          {

            text.val(name);
            divboolean1=false;
            divboolean2=false;
            divboolean3=false;
            divboolean4=false;
            divboolean5=false;
            divboolean6=false;
            divboolean7=false;
            divboolean8=false;
            divboolean9=false;

          });
   			
        update();

   			div1.click(function()
   				{
            if(divboolean1)
            {
              
              divboolean1=false;
              div1.empty();
            total_name+=name[myArray[0]];
            text.val(total_name);
            complete();
            }
   				});

   			div2.click(function()
   				{
            if(divboolean2)
            {
              divboolean2=false;
            div2.empty();
            total_name+=name[myArray[1]];
            text.val(total_name);
            complete();
            }
   				});

   			div3.click(function()
   				{
            if(divboolean3)
            {
              divboolean3=false;
            div3.empty();
            total_name+=name[myArray[2]];
            text.val(total_name);
            complete();
            }
   				});

   			div4.click(function()
   				{
            if(divboolean4)
            {
              divboolean4=false;
                div4.empty();
                total_name+=name[myArray[3]];
                text.val(total_name);
                complete();
            }
   					
   				});
   			div5.click(function()
   				{
            if(divboolean5)
            {
              divboolean5=false;
            div5.empty();
            total_name+=name[myArray[4]];
            text.val(total_name);
            complete();
            }
   				});

   			div6.click(function()
   				{
            if(divboolean6)
            {
              divboolean6=false;
              div6.empty();
            total_name+=name[myArray[5]];
            text.val(total_name);
            complete();
            }
   					
   				});

   			div7.click(function()
   				{
            if(divboolean7)
            {
              divboolean7=false;
            div7.empty();
            total_name+=name[myArray[6]];
            text.val(total_name);
            complete();
            }
   				});

   			div8.click(function()
   				{
            if(divboolean8)
            {
              divboolean8=false;
            div8.empty();
            total_name+=name[myArray[7]];
            text.val(total_name);
            complete();
            }
   				});
   			div9.click(function()
   				{
            if(divboolean9)
            {
              divboolean9=false;
            div9.empty();
            total_name+=name[myArray[8]];
            text.val(total_name);
            complete();
            }
   				});



          function update()
          {
              div1.each(function () 
        {
          characters = name[myArray[0]];
           $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
      div2.each(function () 
        {
          characters = name[myArray[1]];
           $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
        
      });
      div3.each(function () 
        {
          var characters = name[myArray[2]];
          $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
      div4.each(function () 
        {
          var characters = name[myArray[3]];
          $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
      div5.each(function () 
        {
          var characters = name[myArray[4]];
          $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
      div6.each(function () 
        {
          var characters = name[myArray[5]];
          $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
      div7.each(function () 
        {
          var characters = name[myArray[6]];
          $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
      div8.each(function () 
        {
          var characters = name[myArray[7]];
          $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
      div9.each(function () 
        {
          var characters = name[myArray[8]];
          $this = $(this);
          $this.empty();
          $this.append("<span>" + characters + "</span");
      });
          }

   		function lasttime()
      {
          if(typeof(Storage)!=="undefined")
          {
              localStorage.setItem("no",tim);

              time_tag.text(localStorage.getItem("no"));
              timestart();
              //alert();
          }
         
      }

      restart_btn.click(function()
        {
          if(next_level)
          {
            tim=remain_time+tim;
            location.reload();
            restart_div.slideUp();
            update();
          }
          else
          {
            tim=remain_time+tim;
            location.reload();
          }
          
        });
      
			
			function complete()
			{

				count++;
				if(count==9)
				{
					if(total_name==country[sr])
					{
						 restart_div.slideDown();
             tim=0;
             time_tag.text(tim);
             restart_btn.html("Successfully Completed!!!");
              restart_btn.focus();
              next_level=true;

					}
					else
					{
             restart_div.slideDown();
             restart_btn.html("Sorry your loss the game");
              restart_btn.focus();
              next_level=false;
              times=1;
					}
					count=0;
				}
				else
				{
					//alert("Sorry your loss the game");
				}
			}

			function timestart()
			{
				times--;
        if(times%50==0)
        {
          tim--;
          time_tag.text(tim);
          //time_tag.text(parseInt(time_tag.text())+1);
        }
				//time_tag.text(times);
				if(times>0 && total_name!=country[sr])
				{
					requestAnimationFrame(timestart);
				}

				if(times==0)
				{
					complete();

          restart_div.slideDown();
             restart_btn.html("Sorry your loss the game");
              restart_btn.focus();
              next_level=false;
				}
				

			}

	});
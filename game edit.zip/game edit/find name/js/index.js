$(document).ready(function() {

var div1=$("#div_1");
var div2=$("#div_2");
var div3=$("#div_3");

div1.text("H")
div2.text("P")
div3.text("L")
    
  $('#btnPlayCircle').click(function() {
    x = 3
  /*  $('#textholder').css("opacity", "0");
    $('#btnPlayCircle').css("top", "-5em");
    $('#btnPlayShadow').css("height", "0px");
    $('#btnPlayShadow').css("width", "0px");
    $('#btnPlayShadow').css("left", "54%");*/
    $('#btnPlayCircle').hide();
    $('#btnPlayShadow').hide();
    $(".first_screen").hide();
     $(".game_screen").show();
    
  });
  var x = 1;
  function start() {
    if (x == 1) {
    $('#btnPlayCircle').css("margin-top", "-70px");
    $('#btnPlayShadow').css("height", "25px");
    $('#btnPlayShadow').css("width", "25px");
    $('#btnPlayShadow').css("border-radius", "25px");
    $('#btnPlayShadow').css("left", "51.1%");
    $('#btnPlayShadow').css("opacity", "0.3");
  setTimeout(start, 1000);
      x = 2
    } else if(x == 2){
    $('#btnPlayCircle').css("margin-top", "-37.5px");
    $('#btnPlayShadow').css("height", "50px");
    $('#btnPlayShadow').css("width", "50px");
    $('#btnPlayShadow').css("border-radius", "50px");
    $('#btnPlayShadow').css("left", "50%");
    $('#btnPlayShadow').css("opacity", "0.5");
      setTimeout(start, 1000);
      x = 1
  }
}
start();


$(".divs").click(function()
  {

    var ids=this.id;
    show(ids);

  });

function show(id)
{
  var text = $('#'+id).text()
  alert(text);
  $('#'+id).text("");
}

});